# Mega Club Auto Booker v1

This is a cloud-ready first version of the automation.

## What it does

- Toronto timezone
- Weekdays: 19:00–22:00
- Weekends: 12:00–22:00
- Badminton is checked first on Mon/Fri/Sat/Sun
- Tennis is fallback and is checked on all days
- Stops after the first successful booking
- Sends an email after success
- Uses a local state file to reduce duplicate runs
- `DRY_RUN=true` is the safe default

## Important

Do NOT paste your SimplyBook password into ChatGPT. Put it in the deployment platform's private environment/secret settings.

SimplyBook's current API documentation lists `getUserToken`, `getStartTimeMatrix`, and `book`. However, a real deployment must first be tested against the specific Mega Club account because required client fields, authentication/2FA, and service/unit permissions can vary.

## First test

1. Deploy the container/script to a private server.
2. Set `DRY_RUN=true`.
3. Set credentials and email SMTP secrets privately.
4. Set `RELEASE_DATE` to a future date that is actually open for booking.
5. Run once.
6. Confirm the logs show the expected Badminton/Tennis service and candidate time.
7. Only then set `DRY_RUN=false`.

## Release timing

The user reports that Mega Club opens one additional day at midnight each night. The scheduler should run immediately after midnight Toronto time and set `RELEASE_DATE` to the newly opened date. If the site's actual release behavior differs, change that date calculation before enabling live booking.

## Gmail

For Gmail SMTP, use a Google App Password if the account has 2-Step Verification. Never use the normal Gmail password as SMTP_PASSWORD.

## Security

Use a private repository/server. Never commit `.env`, state files, or passwords.
